package com.example.demo.controller

import com.example.demo.model.Product
import com.example.demo.service.AmazonClient
import com.example.demo.service.ProductService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile

@RestController
@RequestMapping("/product")
class ProductController {
    @Autowired
    private lateinit var iproductService: ProductService
    @Autowired
    private lateinit var amazonClient: AmazonClient

    fun BucketController(amazonClient: AmazonClient?) {
        if (amazonClient != null) {
            this.amazonClient = amazonClient
        }
    }
    @PostMapping("/addProduct")
    fun addProduct(@RequestParam("pid")  pid:String,
                   @RequestParam("sellerEmail")  sellerEmail: String,
                   @RequestParam("name")  Name: String,
                   @RequestParam("weight")  weight: String,
                   @RequestParam("description")  description: String,
                   @RequestParam("images")  file: MultipartFile,
                  ): ResponseEntity<Any?> {
        val newProd=Product(
        pid,sellerEmail,Name,weight,description,amazonClient.uploadFile(file))
        val addProduct = iproductService.addProduct(newProd)
        return ResponseEntity(addProduct, HttpStatus.OK)
    }
    @GetMapping("/getAllProduct")
    fun getAllProduct(): ResponseEntity<MutableList<Product?>>
    {
        val Productlist = iproductService.getAllProduct()
        return ResponseEntity(Productlist, HttpStatus.OK)
    }
}