package com.example.demo.controller

import com.example.demo.DAO.CartRepository
import com.example.demo.DTO.AttachmentDTO
import com.example.demo.DTO.mailDataDTO
import com.example.demo.DTO.mailMessageDTO
import com.example.demo.model.Product
import com.example.demo.model.cart
import com.example.demo.service.EmailSenderService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/mail")
class MailController
{
    @Autowired
    private  lateinit var EmailSenderService : EmailSenderService
    @Autowired
    private lateinit var icartrepository:CartRepository
    @PostMapping("/sent")
    fun sendmail(@RequestBody mailDataDTO: mailDataDTO): ResponseEntity<Any>
    { val mail=mailMessageDTO()
        mail.mailID=mailDataDTO.mailID
        mail.subject=mailDataDTO.subject
        mail.message="Your order\n"+
                "Cart id=${mailDataDTO.cart!!.cid}\n"+
                "Product id= ${mailDataDTO.cart!!.product.pid}\n"+
                "Product name= ${mailDataDTO.cart!!.product.Name}\n"+
                "Product description= ${mailDataDTO.cart!!.product.description}\n"+
                "Product Image=${mailDataDTO.cart!!.product.ImageName}\n"



       EmailSenderService.sendSimpleEmail(mail.mailID,mail.message,mail.subject)
       icartrepository.deleteById(mailDataDTO.cart!!.cid)

        return ResponseEntity.ok(mail.message)
    }
    @PostMapping("/sentFile")
    fun sendFiles(@RequestBody attachmentDTO: AttachmentDTO): ResponseEntity<AttachmentDTO>
    {
        EmailSenderService.sendEmailWithAttachment(attachmentDTO.mailID, attachmentDTO.message, attachmentDTO.subject, attachmentDTO.fileUrl)
        return ResponseEntity.ok(attachmentDTO)
    }

}