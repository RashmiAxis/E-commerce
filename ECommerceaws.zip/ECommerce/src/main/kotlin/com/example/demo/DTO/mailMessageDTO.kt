package com.example.demo.DTO

import com.example.demo.model.Product
import com.example.demo.model.cart
import com.example.demo.model.seller

class mailMessageDTO {
    var mailID: String?=null
    var subject: String?=null
    var message: String?=null


    /*   constructor(mailID: String?, subject: String?, message: String?,sellerEmail: String?,Cart: cart) {
        this.mailID = mailID
        this.subject = subject
        this.message = message
        this.sellerEmail=sellerEmail
        this.cart=cart
    }*/

    constructor()

}