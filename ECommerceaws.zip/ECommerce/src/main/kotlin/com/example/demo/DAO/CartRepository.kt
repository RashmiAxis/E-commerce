package com.example.demo.DAO


import com.example.demo.model.cart
import org.springframework.data.mongodb.repository.MongoRepository

interface CartRepository: MongoRepository<cart, Int> {
}