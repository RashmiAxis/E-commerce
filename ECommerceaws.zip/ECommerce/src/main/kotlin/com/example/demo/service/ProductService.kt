package com.example.demo.service

import com.example.demo.model.Product

interface ProductService {
    fun addProduct(Product: Product): Product?
    fun getAllProduct(): MutableList<Product?>
}