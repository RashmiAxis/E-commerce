package com.example.demo.controller

import com.example.demo.model.cart
import com.example.demo.service.CartService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import java.util.*

@RestController
@RequestMapping("/cart")
class CartController {
    @Autowired
    private lateinit var icartService: CartService

    @PostMapping("/addCart")
    fun addcart(@RequestBody cart: cart): ResponseEntity<Any?> {
        val addCart = icartService.addcart(cart)
        return ResponseEntity(addCart, HttpStatus.OK)
    }

    @GetMapping("/getAllCart")
    fun getAllcart(): ResponseEntity<MutableList<cart?>>
    {
        var cartList = icartService.getAllcart()
        return ResponseEntity(cartList, HttpStatus.OK)
    }
    @GetMapping("/getcartById/{cid}")
    fun getcartById(@PathVariable cid:Int): ResponseEntity<Optional<cart?>> {
        val cartDetails = icartService.getcartById(cid)
        return ResponseEntity(cartDetails, HttpStatus.OK)

    }
    @DeleteMapping("/deleteById/{cid}")
    fun deletecartById(@PathVariable cid: Int): ResponseEntity<String?>
    {
        var deletecart = icartService.deletecart(cid)
        return ResponseEntity(deletecart, HttpStatus.OK)
    }
}