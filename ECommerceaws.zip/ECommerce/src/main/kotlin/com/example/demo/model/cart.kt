package com.example.demo.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType

@Document(collection = "cart")
class cart (
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    var cid:Int=0,
    var product: Product,


        )