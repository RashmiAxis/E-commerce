package com.example.demo.DAO


import com.example.demo.model.seller
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface SellerRepository: MongoRepository<seller, Int> {
    fun findByEmail(email:String): seller?
}