package com.example.demo.DTO

class LoginDTO {
    val email = ""
    val password = ""
}