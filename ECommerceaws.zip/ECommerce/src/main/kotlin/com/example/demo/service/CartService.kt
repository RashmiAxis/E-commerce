package com.example.demo.service

import com.example.demo.model.cart
import java.util.*

interface CartService {
    fun addcart(ncart: cart):Any?
    fun getAllcart(): MutableList<cart?>
    fun getcartById(Id: Int): Optional<cart?>
    fun deletecart(id:Int):String
}