package com.example.demo

import com.example.demo.DAO.*
import com.example.demo.model.*
import com.example.demo.service.*
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import org.mockito.BDDMockito.given
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.mock.mockito.MockBean

@SpringBootTest
class ECommerceApplicationTests {

	@Autowired
	private lateinit var iproductService: ProductService
	@Autowired
	private lateinit var sellerService : SellerService
	@Autowired
	private lateinit var  userService : UserService

	@MockBean
	private  lateinit var iproductDAO:ProductDAO
	@MockBean
	private lateinit var isellerRepository:SellerRepository
	@MockBean
	private lateinit var iUserRepository:UserRepository




	@Test
	fun testAddProduct(){
		val testProduct=Product(pid = "12",sellerEmail = "example@gmail.com",weight = "34.4",Name = "icecream",description = "sweet",ImageName = "imagefile")
		given(iproductDAO.save(testProduct)).willReturn(testProduct)
		assertEquals(testProduct,iproductService.addProduct(testProduct))
	}
	@Test
	fun testGetProduct(){
		val testProductList= mutableListOf(Product(pid = "12",sellerEmail = "example@gmail.com",weight = "34.4",Name = "icecream",description = "sweet",ImageName = "imagefile"),
			Product(pid = "123",sellerEmail = "example1@gmail.com",weight = "34.6",Name = "knife",description = "sharp",ImageName = "image1file"),
			Product(pid = "1",sellerEmail = "example2@gmail.com",weight = "34",Name = "book",description = "novel",ImageName = "image2file"),
			Product(pid = "4",sellerEmail = "example3@gmail.com",weight = "20.0",Name = "pencil",description = "hard",ImageName = "image3file"))
		given(iproductDAO.findAll()).willReturn(testProductList)
		assertEquals(testProductList,iproductService.getAllProduct())
	}
	@Test
	fun testSaveSeller(){
		val testSeller=seller(sid = 1,name = "rashmi",email = "example@gmail.com",password = "rashmi1")
		given(isellerRepository.save(testSeller)).willReturn(testSeller)
		assertEquals(testSeller,sellerService.saveseller(testSeller))
	}
	@Test
	fun testFindByEmail(){
		val testEmail=seller(sid = 1,name = "rashmi",email = "example@gmail.com",password = "rashmi1")
		given(isellerRepository.findByEmail(testEmail.email)).willReturn(testEmail)
		assertEquals(testEmail,sellerService.findByEmail(testEmail.email))
	}
    @Test
	fun testSaveUser(){
		val testUser=User(_id = 1,name = "rashmi",email = "example@gmail.com",password = "rashmi")
		given(iUserRepository.save(testUser)).willReturn(testUser)
		assertEquals(testUser,userService.save(testUser))
	}
    @Test
	fun testByEmail(){
		val testEmail=User(_id = 1,name = "rashmi",email = "example@gmail.com",password = "rashmi")
		given(iUserRepository.findByEmail(testEmail.email)).willReturn(testEmail)
		assertEquals(testEmail,userService.findByEmail(testEmail.email))
	}


}
