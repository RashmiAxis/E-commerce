package com.example.demo.service

import com.example.demo.DAO.SellerRepository
import com.example.demo.DAO.UserRepository
import com.example.demo.model.User
import com.example.demo.model.seller
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class SellerService {
    @Autowired
    private val sellerRepository: SellerRepository?=null

    fun saveseller(seller: seller): seller {
        return this.sellerRepository!!.save(seller)
    }

    fun findByEmail(email: String): seller? {
        return this.sellerRepository!!.findByEmail(email)
    }

    fun sellergetById(id: Int): Any {
        return this.sellerRepository!!.findById(id)
    }
}