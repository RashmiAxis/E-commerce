package com.example.demo.DTO

class Message(public val message: String) {
}