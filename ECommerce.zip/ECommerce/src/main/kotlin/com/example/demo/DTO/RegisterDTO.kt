package com.example.demo.DTO

class RegisterDTO {
    val name = ""
    val email = ""
    val password = ""
}