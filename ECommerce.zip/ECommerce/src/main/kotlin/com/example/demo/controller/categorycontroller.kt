package com.example.demo.controller

import com.example.demo.model.category
import com.example.demo.service.categoryservice
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/category")
class categorycontroller {
    @Autowired
    private lateinit var icategoryService: categoryservice

    @PostMapping("/addCategory")
    fun addCategory(@RequestBody category: category): ResponseEntity<Any?> {
        val addCategory = icategoryService.addCategory(category)
        return ResponseEntity(addCategory, HttpStatus.OK)
    }
    @GetMapping("/getAllCategory")
    fun getAllCategory(): ResponseEntity<MutableList<category?>>
    {
        val catlist = icategoryService.getAllCategory()
        return ResponseEntity(catlist, HttpStatus.OK)
    }
}