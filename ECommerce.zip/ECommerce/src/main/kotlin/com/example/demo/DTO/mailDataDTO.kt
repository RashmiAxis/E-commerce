package com.example.demo.DTO

import com.example.demo.model.Product
import com.example.demo.model.cart

class mailDataDTO {
    var mailID: String?=null
    var subject: String?=null
    var message: String?=null
    var sellerEmail: String?=null
    //var product: Product?=null
    var cart:cart?=null

    constructor()
}