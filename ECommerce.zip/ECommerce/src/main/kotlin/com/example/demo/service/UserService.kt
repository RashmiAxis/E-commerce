package com.example.demo.service

import com.example.demo.DAO.UserRepository
import com.example.demo.model.Product
import com.example.demo.model.User
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.mail.SimpleMailMessage
import org.springframework.stereotype.Service
import org.springframework.mail.javamail.JavaMailSender

@Service
class UserService {
    @Autowired
    private val userRepository: UserRepository?=null

    fun save(user: User): User {
        return this.userRepository!!.save(user)
    }

    fun findByEmail(email: String): User? {
        return this.userRepository!!.findByEmail(email)
    }

    fun getById(id: Int): Any {
        return this.userRepository!!.findById(id)
    }



}