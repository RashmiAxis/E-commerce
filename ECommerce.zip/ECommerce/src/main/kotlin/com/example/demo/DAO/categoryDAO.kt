package com.example.demo.DAO

import com.example.demo.model.category
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface categoryDAO: MongoRepository<category, Int> {
}