package com.example.demo.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document


@Document(collection = "category")
class category (

    @Id
    var id: Int,
    var name: String,

    )