package com.example.demo.service

import com.example.demo.DAO.CartRepository
import com.example.demo.model.Product
import com.example.demo.model.cart
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service
import java.util.*
import kotlin.jvm.Throws

@Service
class CartImpl:CartService {
    @Autowired
    private lateinit var icartrepository: CartRepository

    override fun addcart(ncart: cart): Any? {
        return  icartrepository.save(ncart)
    }

    override fun getAllcart(): MutableList<cart?> {
        return icartrepository.findAll()
    }

    @Throws(Exception::class)
    override fun getcartById(cid: Int): Optional<cart?> {
        return icartrepository.findById(cid)
    }




    override fun deletecart(cid: Int): String {
        return if(icartrepository.existsById(cid))
        {
            icartrepository.deleteById(cid)
            "deleted"
        }
        else {
            "cart with id $cid not found"
        }
    }
    }

