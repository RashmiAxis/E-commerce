package com.example.demo.model

import org.springframework.data.annotation.Id

class Product (
    @Id
    var pid:Int,
    var sellerEmail:String = "",
    var Name:String,
    var weight:String,
    var description:String,
    var ImageName:String,

)