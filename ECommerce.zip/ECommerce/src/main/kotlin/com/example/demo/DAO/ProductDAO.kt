package com.example.demo.DAO

import com.example.demo.model.Product
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.stereotype.Repository

@Repository
interface ProductDAO: MongoRepository<Product, Int> {
}