package com.example.demo.service

import com.example.demo.model.category

interface categoryservice {
    fun addCategory(category: category): category?
    fun getAllCategory(): MutableList<category?>
}