package com.example.demo.DTO

class sellerRegisterDTO {
    val name = ""
    val email = ""
    val password = ""
}