package com.example.demo.model

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import javax.persistence.GeneratedValue
import javax.persistence.GenerationType

@Document(collection="sellercredential")
class seller (
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    var sid: Int = 0,
    var name:String,
    var email:String,
    var password:String,
    /*   @JsonIgnore
get() = field

set(value) {
   val passwordEncoder = BCryptPasswordEncoder()
   field = passwordEncoder.encode(value)
}
fun comparePassword(password: String): Boolean {
return BCryptPasswordEncoder().matches(password, this.password)
}*/
)