package com.example.demo.service

import com.example.demo.DAO.categoryDAO
import com.example.demo.model.category
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class categoryImpl : categoryservice{
    @Autowired
    private lateinit var icategoryDAO: categoryDAO
    override fun addCategory(category: category): category? {
        return icategoryDAO.save(category)
    }
    override fun getAllCategory():MutableList<category?>{
        return icategoryDAO.findAll()
    }
}