package com.example.demo.controller

import com.example.demo.DTO.Message
import com.example.demo.DTO.sellerLoginDTO
import com.example.demo.DTO.sellerMessage
import com.example.demo.model.seller
import com.example.demo.service.SellerService
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.ResponseEntity
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.web.bind.annotation.*
import java.util.*
import javax.servlet.http.Cookie
import javax.servlet.http.HttpServletResponse


@RestController
@RequestMapping("sellerapi")
class sellerAuthController {

    @Autowired
    private val sellerService : SellerService?=null
    private val passwordEncoder = BCryptPasswordEncoder()

    @PostMapping("sellerregister")
    fun register(@RequestBody userBody: seller): ResponseEntity<seller> {
        val seller = seller(userBody.sid,userBody.name,userBody.email,passwordEncoder.encode(userBody.password))
        return ResponseEntity.ok(sellerService!!.saveseller(seller))
    }

    @PostMapping("sellerlogin")
    fun login(@RequestBody body: sellerLoginDTO, response: HttpServletResponse): ResponseEntity<Any> {
        val seller = this.sellerService!!.findByEmail(body.email)
            ?: return ResponseEntity.badRequest().body(sellerMessage("user not found!"))


        if (!passwordEncoder.matches(body.password,seller.password)) {
            return ResponseEntity.badRequest().body(sellerMessage("invalid password!"))
        }

        val sissuer = seller.sid.toString()

        val jwt = Jwts.builder()
            .setIssuer(sissuer)
            .setExpiration(Date(System.currentTimeMillis() + 60 * 24 * 1000)) // 24 min
            .signWith(SignatureAlgorithm.HS512, "secret").compact()

        val cookie = Cookie("jwt", jwt)
        cookie.isHttpOnly = true

        response.addCookie(cookie)

        return ResponseEntity.ok(sellerMessage("success"))
    }

    @GetMapping("seller")
    fun user(@CookieValue("jwt") jwt: String?): ResponseEntity<Any> {
        try {
            if (jwt == null) {
                return ResponseEntity.status(401).body(Message("unauthenticated"))
            }

            val body = Jwts.parser().setSigningKey("secret").parseClaimsJws(jwt).body

            return ResponseEntity.ok(this.sellerService!!.sellergetById(body.issuer.toInt()))
        } catch (e: Exception) {
            return ResponseEntity.status(401).body(sellerMessage("unauthenticated"))
        }
    }

    @PostMapping("sellerlogout")
    fun logout(response: HttpServletResponse): ResponseEntity<Any> {
        val cookie = Cookie("jwt", "")
        cookie.maxAge = 0

        response.addCookie(cookie)

        return ResponseEntity.ok(sellerMessage("success"))
    }
}