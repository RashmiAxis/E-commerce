package com.example.demo.DTO

class sellerLoginDTO {
    val email = ""
    val password = ""
}