package com.example.demo.DTO

class sellerMessage(public val message: String) {
}