package com.example.demo.service

import com.example.demo.DAO.ProductDAO
import com.example.demo.model.Product
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ProductImpl: ProductService {
    @Autowired
    private lateinit var iproductDAO: ProductDAO

    override fun addProduct(Product: Product): Product? {
        return  iproductDAO.save(Product)
    }

    override fun getAllProduct(): MutableList<Product?> {
        return iproductDAO.findAll()
    }
}