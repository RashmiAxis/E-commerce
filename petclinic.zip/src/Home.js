import Navi from './component/Nav';
import bg from './images/c.jpg';
import './home.css';

const Home=()=>{
    return(
        <div className="home">
            <Navi/>
            <img className="home_image" src={bg}  alt="" />
            
         <p className='tiff'>Welcome User</p>

        </div>
        
    )
}
export default Home;