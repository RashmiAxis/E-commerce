import Navi from './component/Nav';
import bg from './images/c.jpg';
import './home.css';
import Product from './Product/Product';

const Home=()=>{
    return(
        <div className="home">
            <Navi/>
            <img className="home_image" src={bg}  alt="" />
            
         <p className='tiff'>Welcome User</p>
         <div className='home_row'>
           <Product
           image="https://media.wired.com/photos/5f401ecca25385db776c0c46/master/pass/Gear-How-to-Apple-ios-13-home-screen-iphone-xs-06032019_big_large_2x.jpg" />
           
         </div>

        </div>
        
    )
}
export default Home;