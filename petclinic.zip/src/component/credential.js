import React,{useEffect} from "react";
import { Card,CardBody,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";

const user=({user})=>{

    return(
        <Card className="text-center">
            
          <CardBody>
          
              <CardSubtitle className="font-weight-bold">{user.id}</CardSubtitle>
              <CardText>{user.name}</CardText>
              <CardText>{user.email}</CardText>
              <CardText>{user.password}</CardText>
              
          </CardBody>
        </Card>
    )
    


    
}
export default user;