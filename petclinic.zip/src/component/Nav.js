import React,{useEffect} from 'react';
import {Navbar, Nav, NavDropdown,} from 'react-bootstrap'
import { Button, Container, Form,Offcanvas, ListGroupItem} from "reactstrap";
import { BrowserRouter as Router,Route,Link,Switch} from "react-router-dom";
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';





const Navi=()=>{
   
    return(
        <div >
           <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
  <Container>
  <Navbar.Brand href="#home">E-Commerce Website</Navbar.Brand>
  <Navbar.Toggle aria-controls="responsive-navbar-nav" />
  <Navbar.Collapse id="responsive-navbar-nav">
    <Nav className="me-auto">
      <Nav.Link tag="a" to="/">Home</Nav.Link>
      <Nav.Link href="#pricing">About Us</Nav.Link>
      <NavDropdown title="Dropdown" id="collasible-nav-dropdown">
        <NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
      </NavDropdown>
    </Nav>
    <Nav className='header_link'>
      <Link tag="a" to="/login" action><Button color="success" >User Login</Button></Link>
      <Link eventKey={2} tag="a" to="/register"><Button color="danger" style={{marginLeft:"15px"}} > Seller Login</Button>
      </Link>
      <Link tag="a" to="/checkout" style={{marginLeft:"15px"}}>
      <ShoppingCartIcon/>
      <span className="header_optionLineTwo header__basketCount">2</span>
      </Link>
    </Nav>
  </Navbar.Collapse>
  </Container>
</Navbar>

        </div>
    )
}
export default Navi;