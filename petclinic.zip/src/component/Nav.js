import React,{useEffect, useState} from 'react';
import {Navbar, Nav, NavDropdown,} from 'react-bootstrap'
import { Button, Container, Form,Offcanvas, ListGroupItem} from "reactstrap";
import { BrowserRouter as Router,Route,Link,Switch,useNavigate} from "react-router-dom";
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import CartIcon from './carticon';






const Navi=()=>{
  const[islogin,setIslogin]=useState(false);
  const navigate=useNavigate();
  useEffect(()=>{
    const user=JSON.parse(localStorage.getItem('usercredential'))
    if(user !== null)
    {setIslogin(true)}
   },[])
   function logout(){
    localStorage.removeItem('usercredential')
    setIslogin(false)
    navigate('/')
  }
   if(islogin===true)
   {

  
   
    return(
        <div >
           <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
  <Container>
  <Navbar.Brand href="#home">E-Commerce Website</Navbar.Brand>
  <Navbar.Toggle aria-controls="responsive-navbar-nav" />
  <Navbar.Collapse id="responsive-navbar-nav">
    <Nav className="me-auto">
      <Nav.Link tag="a" to="/">Home</Nav.Link>
      <Nav.Link href="#pricing">About Us</Nav.Link>
      <NavDropdown title="Category" id="collasible-nav-dropdown">
        <NavDropdown.Item href="#action/3.1">Cake</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.2">Electronic</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
      </NavDropdown>
    </Nav>
    <Nav className='header_link'>
      <Link tag="a" to="/" onClick={logout} action><Button color="success" >Logout</Button></Link>
     
      

        <Link tag="a" to="/checkout" style={{marginLeft:"15px"}}>
         <CartIcon/>
         
        {/* <ShoppingCartIcon/> 
       <span className="header_optionLineTwo header__basketCount">2</span> */}
       </Link>
      
    </Nav>
  </Navbar.Collapse>
  </Container>
</Navbar>

        </div>
    )}
    else{
      return(
        <div >
        <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
<Container>
<Navbar.Brand href="#home">E-Commerce Website</Navbar.Brand>
<Navbar.Toggle aria-controls="responsive-navbar-nav" />
<Navbar.Collapse id="responsive-navbar-nav">
 <Nav className="me-auto">
   <Nav.Link tag="a" to="/">Home</Nav.Link>
   <Nav.Link href="#pricing">About Us</Nav.Link>
   <NavDropdown title="Category" id="collasible-nav-dropdown">
     <NavDropdown.Item href="#action/3.1">Cake</NavDropdown.Item>
     <NavDropdown.Item href="#action/3.2">Electronic</NavDropdown.Item>
     <NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
   </NavDropdown>
 </Nav>
 <Nav className='header_link'>
   <Link tag="a" to="/login" action><Button color="success" >User Login</Button></Link>
   <Link eventKey={2} tag="a" to="/sellerlogin"><Button color="danger" style={{marginLeft:"15px"}} > Seller Login</Button>
   </Link>
  
 </Nav>
</Navbar.Collapse>
</Container>
</Navbar>

     </div>
      )
    }
}
export default Navi;