
import React,{useEffect} from "react";
import { Card,CardBody,CardTitle,CardSutitle,CardText,CardFooter,Button,Container, CardSubtitle } from "reactstrap";

const signin=({signin})=>{
    return(
        <div>
            <Card className="text-center">
            
            <CardBody>
            
                <CardSubtitle className="font-weight-bold">{signin.name}</CardSubtitle>
                <CardText>{signin.password}</CardText>
                
            </CardBody>
          </Card>
        </div>)}
        export default signin;