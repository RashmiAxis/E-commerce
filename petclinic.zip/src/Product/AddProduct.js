import { Button, Form,FormGroup,Input ,Label,ListGroup, } from "reactstrap";
import React,{Fragment, useEffect,useState} from "react";
import { Link,useNavigate } from "react-router-dom";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
import axios from "axios";
import './Product.css';
import Navi from '../component/Nav';

const AddProduct=()=>{
    useEffect(()=>{
        document.title="E-commerce";
    },[]);
    const[addproduct,setAddProduct]=useState({pid:"",sellerEmail:"",name:"",weight:"",description:"",images:[]});

    const handleForm=(e)=>{
        postProducttoserver(addproduct);
        e.preventDefault();
        //console.log(addproduct);
      };
      
    const postProducttoserver=(data)=>{
        let formdata = new FormData();
        formdata.append("pid",data.pid)
        formdata.append("sellerEmail", data.sellerEmail)
        formdata.append("name", data.name)
        formdata.append("weight", data.weight)
        formdata.append("description", data.description)
        formdata.append("images", data.images)
        console.log(formdata);

          axios.post(`${base_url}/product/addProduct`,formdata).then(
          
            (response)=>{
              console.log(response);
              console.log("success");
                    toast.success("Sucessfully Added");
            },
            (error)=>{
              console.log(error);
              console.log("error");
                    toast.error("Error");
     
            }
          );
      };
    return(
        <div className="product_back">
          <Navi/>
          <div className="container-fluid" >
        <div className="product">
          <div className="product_container">
        <h1 className="text-center my-3">Product Details</h1><hr/>
        <form onSubmit={handleForm} >
            <div class="mb-2">
            <div class="form-group">
                   <label for="exampleInputid">Product Id</label>
                   <input type="text" name="pid" class="form-control" id="pid" onChange={(e)=>{setAddProduct({...addproduct,pid:e.target.value});}} aria-describedby="idHelp" />
              
              
              <div class="mb-3">
                  <label for="sellerEmail" class="form-label">Email </label>
                    <input type="email" name="sellerEmail" class="form-control" id="sellerEmail" onChange={(e)=>{setAddProduct({...addproduct,sellerEmail:e.target.value});}} aria-describedby="emailHelp"></input>
                     
              </div>
              <div class="mb-3">
                  <label for="name" class="form-label">Product name</label>
                    <input type="text" name="name" class="form-control" id="name" onChange={(e)=>{setAddProduct({...addproduct,name:e.target.value});}} aria-describedby="Name"></input>
                     
              </div>
              <div class="mb-3">
                  <label for="weight" class="form-label">Product weight</label>
                    <input type="text" name="weight" class="form-control" id="weight" onChange={(e)=>{setAddProduct({...addproduct,weight:e.target.value});}} aria-describedby="emailHelp"></input>
                     
              </div>
              <div class="input-group mb-3">
                  <label for="description" class="form-label"> Description</label>
                  <textarea  class="form-control" id="description" name="description" rows="5" cols="50" onChange={(e)=>{setAddProduct({...addproduct,description:e.target.value});}} />
              </div>
              <div class="input-group mb-3">
                     <label class="input-group-text" for="inputGroupFile01">Upload</label>
                     <input type="file" class="form-control" id="images" onChange={(e)=>{setAddProduct({...addproduct,images:e.target.files[0]});}} name="images"></input>
            </div>
             
                      <button type="submit" style={{marginLeft:"220px"}} class="btn btn-success">Submit</button>
                     <Link tag="a" to="/" className="absolute" action> <button type="submit" style={{marginLeft:"15px"}} class="btn btn-danger">Cancel</button></Link>
                      </div>
                      </div>
          </form>
  </div>
</div>
</div>
         
          
       </div>
    )
}
export default AddProduct;