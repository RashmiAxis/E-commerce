import React, { useState,useEffect} from "react";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import base_url from "../api/bootapi";
import './Product.css';


const Product=({pid,sellerEmail,Name,weight,description,image})=>{

    useEffect(()=>{
        document.title="E-commerce";
        getproductdatatoserver();
    },[]);

    const[product,setProduct]=useState([]);

     //function to call server
     async function getproductdatatoserver (){
    await axios.get(`${base_url}/product/getAllProduct`).then(
        (response)=>{
             //for success
           console.log(response.data);
            toast.success("Sucessfully Uploaded");
            setProduct(()=>response.data);

           
        },
         (error)=>{
            //for error
             console.log(error);
            toast.error("Error");
        }
    )
 }
 console.log(product);
 return(
     <div>
         <div class="row row-cols-1 row-cols-md-2">
          {product.map(item =>{  
    return(     
  <div class="col-md-4">
    <div class="card">
      <div class="card-body">
      <img src={item.imageName}class="card-img-top" alt=""/>
        <h5 class="card-title">{item.pid}</h5>
        <p class="card-text">{item.description}.</p>
        <a href="#" class="btn btn-warning">Add to Cart</a>
      </div>
    </div>
  </div>    
    )})}</div>
    </div>
 )
}
export default Product;