import React, { useState,useEffect} from "react";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import base_url from "../api/bootapi";
import './Product.css';


const Product=({pid,sellerEmail,Name,weight,description,image})=>{

    useEffect(()=>{
        document.title="E-commerce";
        getproductdatatoserver();
    },[]);

    const[product,setProduct]=useState([]);
    //const[nproduct,setNproduct]=useState([{}]);

    const handleForm=(pid,sellerEmail,name,weight,description,imageName)=>{
      const data1={  cid:pid,
      product:{pid:pid,sellerEmail:sellerEmail,Name:name,weight:weight,description:description,ImageName:imageName}
      }
      
        
      postproductDatatoserver(data1);
      
      
    };
    const postproductDatatoserver=(data1)=>{
      console.log(data1);
      axios.post(`${base_url}/cart/addCart`,data1).then(
        
         (response)=>{
           console.log(response);
           console.log("success");
                 toast.success("Sucessfully Added");
         },
         (error)=>{
           console.log(error);
           console.log("error");
                 toast.error("Error");
    
         }
      );
    }

     //function to call server
     async function getproductdatatoserver (){
    await axios.get(`${base_url}/product/getAllProduct`).then(
        (response)=>{
             //for success
           console.log(response.data);
            toast.success("Sucessfully Uploaded");
            setProduct(()=>response.data);

           
        },
         (error)=>{
            //for error
             console.log(error);
            toast.error("Error");
        }
    )
 }
 console.log(product);
 return(
     <div>
         <div class="row row-cols-1 row-cols-md-2">
          {product.map(item =>{  
    return(     
  <div class="col-md-4">
    <div class="card">
      <div class="card-body">
      
        <h5 class="card-title">{item.pid}</h5>
        <h5 class="card-title">{item.sellerEmail}</h5>
        <h5 class="card-title">{item.name}</h5>
        <h5 class="card-title">{item.weight}</h5>

        <p class="card-text">{item.description}.</p>
        <img src={item.imageName}class="card-img-top" alt=""/>
        <a href="#" class="btn btn-warning" onClick={()=>{handleForm(item.pid,item.sellerEmail,item.name,item.weight,item.description,item.imageName)}}>Add to Cart</a>
      </div>
    </div>
  </div>    
    )})}</div>
    </div>
 )
}
export default Product;