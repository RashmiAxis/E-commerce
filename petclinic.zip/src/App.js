import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Navi from './component/Nav';
import { BrowserRouter as Router,Route,Routes} from "react-router-dom";
import { BrowserRouter } from "react-router-dom";
import Login from './component/Login';
import Home from './Home';
import Register from './component/Register';



function App() {
  return (
   <>
      
  
      <Router>
        
       <Routes>
      <Route path="/checkout" element={<Navi />}>
      </Route>
      <Route path="/login" element={<Login/>}>
      </Route>
      <Route path="/" element={<Home/>}>
      </Route>
      <Route path="/register" element={<Register/>}></Route>
      </Routes>

      </Router>      
          
        
      
      
    </>
  );
}

export default App;
