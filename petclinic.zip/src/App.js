import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Navi from './component/Nav';
import { BrowserRouter as Router,Route,Routes} from "react-router-dom";
import { BrowserRouter } from "react-router-dom";
import Login from './component/Login';
import Home from './Home';
import Register from './component/Register';
import SellerLogin from './SellerLogin/SellerLogin';
import SellerRegister from './SellerLogin/SellerRegister';
import Cart from './Cart/Cart';



function App() {
  return (
   <>
      
  
      <Router>
        
       <Routes>
      <Route path="/checkout" element={<Navi />}>
      </Route>
      <Route path="/login" element={<Login/>}>
      </Route>
      <Route path="/" element={<Home/>}>
      </Route>
      <Route path="/register" element={<Register/>}></Route>
      <Route path="/sellerlogin" element={<SellerLogin/>}></Route>
       <Route path="/cart" element={<Cart/>}></Route> 
      </Routes>

      </Router>      
          
        
      
      
    </>
  );
}

export default App;
