import React, { useState,useEffect} from "react";
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import base_url from "../api/bootapi";
import Navi from "../component/Nav";
import bg from '../images/e.jpg';
import { Button } from "reactstrap";



const Cart=({pid,sellerEmail,Name,weight,description,imageName})=>{

    useEffect(()=>{
        document.title="E-commerce";
        getcartdatatoserver();
    },[]);

    const[cart,setCart]=useState([]);
 
    
    const handleForm=(pid,sellerEmail,name,weight,description,imageName)=>{
      const data1={ mailID:"rashmisinghorneha112@gmail.com",
      subject:"sent",
      message:"hi message sent",
      sellerEmail:"rashmisinghorneha112@gmail.com",  cart:{cid:pid,
      product:{pid:pid,sellerEmail:sellerEmail,Name:name,weight:weight,description:description,ImageName:imageName}
      }}
      
        
      postcartDatatoserver(data1);
      
      
    };
      const postcartDatatoserver=(data1)=>{
         axios.post(`${base_url}/mail/sent`,data1).then(
         
          (response)=>{
            console.log(response);
            console.log("success");
                  toast.success("Sucessfully Added");
          },
          (error)=>{
            console.log(error);
            console.log("error");
                  toast.error("Error");
      
          }
        );
        console.log(data1);
      }

     //function to call server
     async function getcartdatatoserver (){
    await axios.get(`${base_url}/cart/getAllCart`).then(
        (response)=>{
             //for success
           console.log(response.data);
            toast.success("Sucessfully Uploaded");
            setCart(()=>response.data);

           
        },
         (error)=>{
            //for error
             console.log(error);
            toast.error("Error");
        }
    )
 }
 console.log(cart);
 return(
     <div>
     <Navi/>
         <div class="row row-cols-1 row-cols-md-2">
          {cart.map(item =>{  
    return(     
  <div class="col-md-4">
    
    <div class="card">
      <div class="card-body">
      <img src={bg}class="card-img-top" alt=""/>
        <h5 class="card-title">{item.product.pid}</h5>
        <h5 class="card-title">{item.product.name}</h5>
        <p class="card-text">{item.product.description}</p>
        <Button color="warning" onClick={()=>{handleForm(item.product.pid,item.product.sellerEmail,item.product.name,item.product.weight,item.product.description,item.product.imageName)}} outline >Checkout</Button>
      </div>
    </div>
  </div>    
    )})}</div>
    </div>
 )
}
export default Cart;