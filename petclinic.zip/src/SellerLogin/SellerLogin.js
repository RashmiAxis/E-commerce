import React,{Fragment, useEffect,useState} from "react";
import { Link,useNavigate } from "react-router-dom";
import { Button, Container, Form,FormGroup,Input ,Label,ListGroup, ListGroupItem} from "reactstrap";
import axios from "axios";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
import './seller.css';
import Navi from "../component/Nav";

const SellerLogin=()=>{
  const navigate=useNavigate();
   
    const[signin,setSignIn]=useState([]);
    const[loginDetail, setLoginDetail] = useState({userEmail:"",userPassword:"",userRole:""})
    //form handler function
const handleForm=(e)=>{
    postLogindetailstoserver(signin);
    e.preventDefault();
    console.log(signin);
  };
   const postLogindetailstoserver=(data)=>{
    axios.post(`${base_url}/sellerapi/sellerlogin`,data).then(
      
        (response)=>{
          let usercre={email:signin.email,password:signin.password}
          localStorage.setItem('usercredential',JSON.stringify(usercre))
          console.log("success");
               navigate('/addProduct')
        },
        (error)=>{
          console.log(error);
          console.log("error");
                toast.error("Error");
   
        }
      );
    };
    
    return(
      <div className="back">
          <Navi/>
      <div className="container-fluid col-4" style={{}}>
        <div className="login">
          <div className="login_container">
        <h1 className="text-center my-3">Login</h1><hr/>
       <Form onSubmit={handleForm}>
<div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
        <div class="form-group">
<label for="exampleInputemail">Email</label>
<Input type="text" name="email" class="form-control"  onChange={(e)=>{setSignIn({...signin,email:e.target.value});}} aria-describedby="nameHelp" placeholder="Email"/>
</div>
</div>
<div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
<div class="form-group">
<label for="exampleInputpassword">Password</label>
<Input type="password" name="password" onChange={(e)=>{setSignIn({...signin,password:e.target.value});}}class="form-control" password="exampleInputPassword1"  placeholder="Password"/>
</div>
</div><div><hr/>
<Container>
<Button type="submit" className="btn outline-success" style={{marginLeft:"35px"}} color="success" outline type="regiter">Login</Button>
<Link tag="a" to="/sellerregister" className="absolute" action><Button  color="danger" style={{marginLeft:"15px"}} outline>Register?</Button></Link>

</Container>
</div>
</Form>
  </div>
</div>
</div>
</div>
    
)
       
    }
export default SellerLogin;