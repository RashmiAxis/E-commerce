import axios from "axios";
import React,{Fragment, useEffect,useState} from "react";
import { Button, Container, Form,FormGroup,Input ,Label} from "reactstrap";
import { Link } from "react-router-dom";
import base_url from "../api/bootapi";
import { ToastContainer, toast } from 'react-toastify';
import './seller.css';
import Navi from "../component/Nav";


const SellerRegister=()=>{
   
  const[user,setUser]=useState({})
  
 //form handler function
  const handleForm=(e)=>{
    postRegistertoserver(user);
    e.preventDefault();
    console.log(user);
  };
  
  //creating function to post data on server
  const postRegistertoserver=(data)=>{
    axios.post(`${base_url}/sellerapi/sellerregister`,data).then(
      
      (response)=>{
        console.log(response);
        console.log("success");
              toast.success("Sucessfully Registered");
      },
      (error)=>{
        console.log(error);
        console.log("error");
              toast.error("Error");
 
      }
    );
  };
  
      return(
        <div className="back">
            <Navi/>
        <div className="container-fluid col-4" style={{}}>
        <div className="login">
             <div className="login_container">
              <h1 className="text-center my-3">SignUp</h1><hr/>
             <Form onSubmit={handleForm}>
    
     <div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
    <div class="form-group">
      <label for="exampleInputid">UserId</label>
      <Input type="text" name="_id" class="form-control" id="exampleInputid" onChange={(e)=>{setUser({...user,_id:e.target.value});}}aria-describedby="idHelp" placeholder=" UserId"/>
    </div></div> 
    <div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
              <div class="form-group">
      <label for="exampleInputname">Name</label>
      <Input type="text" name="name" class="form-control" name="exampleInputname" onChange={(e)=>{setUser({...user,name:e.target.value});}} aria-describedby="nameHelp" placeholder="Name"/>
    </div>
    </div>
    <div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <Input type="email" name="email" onChange={(e)=>{setUser({...user,email:e.target.value});}} class="form-control" aria-describedby="emailHelp" placeholder="Email"/>
      </div>
    </div>
    <div class="jumbotron" className="text-center" style={{backgroundColor:"lightgray"}}>
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <Input type="password" name="password" onChange={(e)=>{setUser({...user,password:e.target.value});}}class="form-control" password="exampleInputPassword1"  placeholder="Password"/>
     </div>
    </div><div><hr/>
    <Container>
    <Button type="submit"  className="btn outline-success" style={{marginLeft:"35px"}} color="success" outline type="regiter">Register</Button>
     
 <Link tag="a" to="/" className="absolute" action><Button  color="danger" outline  style={{marginLeft:"10px"}}>Cancel</Button></Link>
 
 </Container>
 </div>

  
  </Form>

   </div>
   </div>     
  </div>
  </div>
  
          
      )
  }
  export default SellerRegister;